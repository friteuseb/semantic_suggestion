<?php
defined('TYPO3') or die();

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    'SemanticSuggestion',
    'Suggestions',
    'Semantic Suggestions'
);