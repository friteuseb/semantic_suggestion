<?php
namespace TalanHdf\SemanticSuggestion\Tests\Unit\Service;

use PHPUnit\Framework\TestCase;
use TalanHdf\SemanticSuggestion\Service\PageAnalysisService;
use TYPO3\CMS\Core\Context\Context;
use TYPO3\CMS\Core\Context\LanguageAspect;
use TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface;
use TYPO3\CMS\Core\Cache\CacheManager;
use TYPO3\CMS\Core\Cache\Frontend\FrontendInterface;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Database\Query\QueryBuilder;
use TYPO3\CMS\Core\Database\Connection;
use Psr\Log\LoggerInterface;
use Doctrine\DBAL\Result;



class PageAnalysisServiceTest extends TestCase
{
    protected $pageAnalysisService;
    protected $contextMock;
    protected $configurationManagerMock;
    protected $cacheManagerMock;
    protected $cacheMock;
    protected $connectionPoolMock;
    protected $queryBuilderMock;
    protected $loggerMock;

    protected function setUp(): void
{
    $this->contextMock = $this->createMock(Context::class);
    $this->configurationManagerMock = $this->createMock(ConfigurationManagerInterface::class);
    $this->cacheManagerMock = $this->createMock(CacheManager::class);
    $this->cacheMock = $this->createMock(FrontendInterface::class);
    $this->connectionPoolMock = $this->createMock(ConnectionPool::class);
    $this->queryBuilderMock = $this->createMock(QueryBuilder::class);
    $this->loggerMock = $this->createMock(LoggerInterface::class);

    // Configuration du mock de l'aspect de langue
    $languageAspectMock = $this->createMock(LanguageAspect::class);
    $languageAspectMock->method('getId')->willReturn(0);
    $this->contextMock->method('getAspect')->with('language')->willReturn($languageAspectMock);

    // Configuration des champs analysés
    $this->configurationManagerMock->method('getConfiguration')->willReturn([
        'analyzedFields' => [
            'title' => 1.5,
            'description' => 1.0,
            'keywords' => 2.0,
            'abstract' => 1.2,
            'content' => 1.0
        ]
    ]);

    // Configuration du CacheManager mock
    $this->cacheManagerMock->method('getCache')->willReturn($this->cacheMock);

    // Configuration du ConnectionPool mock
    $this->connectionPoolMock->method('getQueryBuilderForTable')->willReturn($this->queryBuilderMock);

    // Création de l'instance de PageAnalysisService pour les tests
    $this->pageAnalysisService = new PageAnalysisService(
        $this->contextMock,
        $this->configurationManagerMock,
        $this->cacheManagerMock,
        $this->connectionPoolMock,
        $this->loggerMock // Assure-toi que $this->loggerMock est bien un mock de Psr\Log\LoggerInterface
    );
    
}

    /**
     * Test de la méthode preparePageData
     *
     * Vérifie que la méthode prépare correctement les données d'une page
     * en appliquant les pondérations et en récupérant le contenu.
     */
    public function testPreparePageData()
    {
        $page = [
            'uid' => 1,
            'title' => 'Test Page',
            'description' => 'Test Description',
            'keywords' => 'test, page, keywords',
            'abstract' => 'Test Abstract'
        ];
    
        // Mock getPageContent to return an empty string
        $this->pageAnalysisService = $this->getMockBuilder(PageAnalysisService::class)
            ->setConstructorArgs([$this->contextMock, $this->configurationManagerMock, $this->cacheManagerMock, $this->connectionPoolMock])
            ->onlyMethods(['getPageContent'])
            ->getMock();
        $this->pageAnalysisService->method('getPageContent')->willReturn('');
    
        $expectedResult = [
            'title' => ['content' => 'Test Page', 'weight' => 1.5],
            'description' => ['content' => 'Test Description', 'weight' => 1.0],
            'keywords' => ['content' => 'test, page, keywords', 'weight' => 2.0],
            'abstract' => ['content' => 'Test Abstract', 'weight' => 1.2],
            'content' => ['content' => '', 'weight' => 1.0]
        ];
    
        $result = $this->invokeMethod($this->pageAnalysisService, 'preparePageData', [$page]);
    
        $this->assertEquals($expectedResult, $result, 'Les données préparées ne correspondent pas aux attentes.');
        $this->assertArrayHasKey('content', $result, 'Le champ "content" est manquant dans les données préparées.');
        $this->assertEquals('', $result['content']['content'], 'Le contenu de la page devrait être vide.');
        $this->assertEquals(1.5, $result['title']['weight'], 'Le poids du titre devrait être de 1.5');
    }

    /**
     * Test de la méthode analyzePages
     *
     * Vérifie que l'analyse des pages produit les résultats attendus
     * et utilise correctement le cache.
     */
    public function testAnalyzePages()
    {
        // Simulation d'un échec de cache
        $this->cacheMock->method('has')->willReturn(false);
        $this->cacheMock->expects($this->once())->method('set');
    
        // Configuration des mocks pour la base de données
        $connectionMock = $this->createMock(Connection::class);
        $schemaManagerMock = $this->createMock(\Doctrine\DBAL\Schema\AbstractSchemaManager::class);
        $schemaManagerMock->method('listTableColumns')->willReturn([
            'uid' => new \Doctrine\DBAL\Schema\Column('uid', new \Doctrine\DBAL\Types\IntegerType()),
            'title' => new \Doctrine\DBAL\Schema\Column('title', new \Doctrine\DBAL\Types\StringType()),
        ]);
        $connectionMock->method('getSchemaManager')->willReturn($schemaManagerMock);
    
        $this->queryBuilderMock->method('getConnection')->willReturn($connectionMock);
        $this->queryBuilderMock->method('select')->willReturnSelf();
        $this->queryBuilderMock->method('from')->willReturnSelf();
        $this->queryBuilderMock->method('where')->willReturnSelf();
        $this->queryBuilderMock->method('executeQuery')->willReturn(
            $this->createConfiguredMock(\Doctrine\DBAL\Result::class, [
                'fetchAllAssociative' => [
                    ['uid' => 1, 'title' => 'Page 1'],
                    ['uid' => 2, 'title' => 'Page 2']
                ]
            ])
        );
    
        $this->connectionPoolMock->method('getQueryBuilderForTable')->willReturn($this->queryBuilderMock);
    
        $this->pageAnalysisService = new PageAnalysisService(
            $this->contextMock,
            $this->configurationManagerMock,
            $this->cacheManagerMock,
            $this->connectionPoolMock
        );
    
        $result = $this->pageAnalysisService->analyzePages(1, 1);
    
        $this->assertArrayHasKey('results', $result, 'Le résultat devrait contenir une clé "results".');
        $this->assertArrayHasKey('metrics', $result, 'Le résultat devrait contenir une clé "metrics".');
        $this->assertCount(2, $result['results'], 'L\'analyse devrait retourner 2 pages.');
        $this->assertArrayHasKey('executionTime', $result['metrics'], 'Les métriques devraient inclure le temps d\'exécution.');
        $this->assertFalse($result['metrics']['fromCache'], 'Le résultat ne devrait pas provenir du cache pour ce test.');
    }

        /**
         * Test de la méthode calculateSimilarity
         *
         * Vérifie que le calcul de similarité entre deux pages
         * produit des résultats cohérents pour différents scénarios.
         */
        public function testCalculateSimilarity()
        {
            $testCases = [
                [
                    'page1' => ['title' => ['content' => 'TYPO3 CMS', 'weight' => 1.5], 'content' => ['content' => 'TYPO3 is a content management system', 'weight' => 1.0]],
                    'page2' => ['title' => ['content' => 'TYPO3 Extensions', 'weight' => 1.5], 'content' => ['content' => 'Extensions enhance TYPO3 functionality', 'weight' => 1.0]],
                    'expectedMinSimilarity' => 0.15,
                    'expectedMaxSimilarity' => 0.5
                ],
                [
                    'page1' => ['title' => ['content' => 'PHP Programming', 'weight' => 1.5], 'content' => ['content' => 'PHP is a server-side scripting language', 'weight' => 1.0]],
                    'page2' => ['title' => ['content' => 'JavaScript Programming', 'weight' => 1.5], 'content' => ['content' => 'JavaScript is a client-side scripting language', 'weight' => 1.0]],
                    'expectedMinSimilarity' => 0.05,
                    'expectedMaxSimilarity' => 0.45
                ]
            ];

            foreach ($testCases as $index => $testCase) {
                $similarity = $this->invokeMethod($this->pageAnalysisService, 'calculateSimilarity', [$testCase['page1'], $testCase['page2']]);

                $this->assertIsFloat($similarity, "Le cas de test #$index devrait retourner une similarité de type float.");
                
                $this->assertGreaterThanOrEqual(
                    $testCase['expectedMinSimilarity'], 
                    $similarity, 
                    sprintf(
                        "Le cas de test #%d devrait avoir une similarité d'au moins %.2f. Valeur calculée : %.2f",
                        $index,
                        $testCase['expectedMinSimilarity'],
                        $similarity
                    )
                );
                
                $this->assertLessThanOrEqual(
                    $testCase['expectedMaxSimilarity'], 
                    $similarity, 
                    sprintf(
                        "Le cas de test #%d devrait avoir une similarité d'au plus %.2f. Valeur calculée : %.2f",
                        $index,
                        $testCase['expectedMaxSimilarity'],
                        $similarity
                    )
                );
                
                // Utilisation d'une assertion pour afficher la valeur de similarité sans marquer le test comme risqué
                $this->assertTrue(true, sprintf("Cas de test #%d - Similarité calculée : %.5f", $index, $similarity));
            }
        }

    /**
     * Test de la méthode findCommonKeywords
     *
     * Vérifie que la recherche de mots-clés communs entre deux pages
     * fonctionne correctement pour différents scénarios.
     */
    public function testFindCommonKeywords()
    {
        $testCases = [
            [
                'page1' => ['keywords' => ['content' => 'typo3, cms, web, php']],
                'page2' => ['keywords' => ['content' => 'php, typo3, programming, database']],
                'expectedCommon' => ['typo3', 'php'],
                'unexpectedCommon' => ['cms', 'database']
            ],
            [
                'page1' => ['keywords' => ['content' => 'frontend, design, css, html']],
                'page2' => ['keywords' => ['content' => 'backend, php, database, server']],
                'expectedCommon' => [],
                'unexpectedCommon' => ['frontend', 'backend']
            ]
        ];

        foreach ($testCases as $index => $testCase) {
            $commonKeywords = $this->invokeMethod($this->pageAnalysisService, 'findCommonKeywords', [$testCase['page1'], $testCase['page2']]);

            foreach ($testCase['expectedCommon'] as $keyword) {
                $this->assertContains($keyword, $commonKeywords, "Le cas de test #$index devrait contenir le mot-clé commun '$keyword'.");
            }
            foreach ($testCase['unexpectedCommon'] as $keyword) {
                $this->assertNotContains($keyword, $commonKeywords, "Le cas de test #$index ne devrait pas contenir le mot-clé '$keyword'.");
            }
        }
    }

    /**
     * Test de la méthode determineRelevance
     *
     * Vérifie que la détermination de la pertinence basée sur le score de similarité
     * produit les résultats attendus pour différentes valeurs de similarité.
     */
    public function testDetermineRelevance()
    {
        $testCases = [
            ['similarity' => 0.8, 'expectedRelevance' => 'High'],
            ['similarity' => 0.75, 'expectedRelevance' => 'High'],
            ['similarity' => 0.6, 'expectedRelevance' => 'Medium'],
            ['similarity' => 0.5, 'expectedRelevance' => 'Medium'],
            ['similarity' => 0.3, 'expectedRelevance' => 'Low'],
            ['similarity' => 0.1, 'expectedRelevance' => 'Low']
        ];

        foreach ($testCases as $index => $testCase) {
            $relevance = $this->invokeMethod($this->pageAnalysisService, 'determineRelevance', [$testCase['similarity']]);
            $this->assertEquals($testCase['expectedRelevance'], $relevance, "Pour une similarité de {$testCase['similarity']}, la pertinence devrait être {$testCase['expectedRelevance']}.");
        }
    }


    public function testPerformanceWithLargeDataset()
    {
        $numberOfPages = 100; // Ajustez ce nombre selon vos besoins
    
        // Préparez un grand nombre de pages mockées
        $pages = [];
        for ($i = 1; $i <= $numberOfPages; $i++) {
            $pages[] = [
                'uid' => $i,
                'title' => "Page $i",
                'description' => "Description for page $i",
                'keywords' => "keyword1, keyword2, keyword$i",
                'abstract' => "Abstract for page $i"
            ];
        }
    
        
        $this->pageAnalysisService = $this->getMockBuilder(PageAnalysisService::class)
            ->setConstructorArgs([$this->contextMock, $this->configurationManagerMock, $this->cacheManagerMock, $this->connectionPoolMock])
            ->onlyMethods(['getSubpages', 'getPageContent'])
            ->getMock();
        $this->pageAnalysisService->method('getSubpages')->willReturn($pages);
        $this->pageAnalysisService->method('getPageContent')->willReturn('Sample content for performance testing');
    
        $startTime = microtime(true);
        $result = $this->pageAnalysisService->analyzePages(1, 1);
        $endTime = microtime(true);

    
        $executionTime = $endTime - $startTime;
    
        $this->assertCount($numberOfPages, $result['results'], "L'analyse devrait traiter toutes les pages.");
        $this->assertLessThan(10, $executionTime, "L'analyse de $numberOfPages pages devrait prendre moins de 10 secondes.");
    
        // Utilise le logger pour enregistrer le temps d'exécution
        $this->loggerMock->info("Temps d'exécution pour $numberOfPages pages : $executionTime secondes"); 
    }

    /**
     * Méthode utilitaire pour invoquer des méthodes privées/protégées
     *
     * @param object $object Objet sur lequel invoquer la méthode
     * @param string $methodName Nom de la méthode à invoquer
     * @param array $parameters Paramètres à passer à la méthode
     * @return mixed Résultat de l'invocation de la méthode
     */
    protected function invokeMethod($object, $methodName, array $parameters = [])
    {
        $reflection = new \ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);
        return $method->invokeArgs($object, $parameters);
    }

}
