<?php
return [
    'semantic_suggestion_proximity' => [
        'path' => '/semantic-suggestion/proximity',
        'target' => \TalanHdf\SemanticSuggestion\Controller\BackendController::class . '::listAction'
    ],
];